import WhyBuySection from './WhyBuySection';

export default function StatsSection() {
  return <WhyBuySection />;
}
