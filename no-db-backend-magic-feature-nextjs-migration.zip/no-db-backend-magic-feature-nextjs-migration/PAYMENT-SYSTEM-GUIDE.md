# 💳 دليل نظام الدفع والتحميل الآمن - Next.js 14

## 📋 نظرة عامة

نظام متكامل لإدارة المدفوعات والتحميل الآمن للمنتجات الرقمية باستخدام:
- **Next.js 14** (App Router + TypeScript)
- **Vercel Blob Storage** لحفظ السجلات والملفات
- **Ziina Payment Gateway** لمعالجة الدفعات
- **Token-based Security** لحماية التحميلات

---

## 🚀 الإعداد السريع

### 1️⃣ **Environment Variables**

أنشئ ملف `.env.local` في جذر المشروع:

```env
# ═══════════════════════════════════════════════════════════
# 🔑 Vercel Blob Storage
# ═══════════════════════════════════════════════════════════
# للحصول عليه: https://vercel.com/dashboard → Storage → Blob
BLOB_READ_WRITE_TOKEN=vercel_blob_rw_XXXXXXXXXXXXXXXXXXXXXXXXX

# ═══════════════════════════════════════════════════════════
# 🌐 Base URL (للإنتاج)
# ═══════════════════════════════════════════════════════════
NEXT_PUBLIC_BASE_URL=https://leve1up.vercel.app

# ═══════════════════════════════════════════════════════════
# 📱 WhatsApp Support (اختياري)
# ═══════════════════════════════════════════════════════════
# رقم الواتساب للدعم (بدون +)
NEXT_PUBLIC_WHATSAPP_NUMBER=966500000000
```

### 2️⃣ **إعداد Ziina Dashboard**

في لوحة تحكم Ziina، قم بضبط:

#### **Webhook URL:**
```
https://leve1up.vercel.app/api/webhook
```

#### **Success Redirect URL:**
```
https://leve1up.vercel.app/order-success?payment_id={PAYMENT_ID}
```

**ملاحظة:** Ziina قد لا تستبدل `{PAYMENT_ID}` تلقائياً، لكن النظام يعتمد على Webhook لإنشاء الـ token.

#### **Webhook Events:**
- ✅ `payment.completed`

---

## 📁 هيكل الملفات

```
project/
├── app/
│   ├── api/
│   │   ├── webhook/
│   │   │   └── route.ts          # استقبال إشعارات الدفع
│   │   ├── record/
│   │   │   └── route.ts          # جلب بيانات الطلب
│   │   └── download/
│   │       └── [token]/
│   │           └── route.ts      # تحميل آمن للملفات
│   └── order-success/
│       └── page.tsx              # صفحة الفاتورة
├── data/
│   └── products.json             # قاعدة بيانات المنتجات
└── .env.local                    # متغيرات البيئة
```

---

## 📦 إعداد المنتجات

### **1. رفع الملفات إلى Vercel Blob**

```bash
# تثبيت Vercel CLI
npm i -g vercel

# تسجيل الدخول
vercel login

# رفع ملف منتج
vercel blob upload /path/to/product.pdf --token $BLOB_READ_WRITE_TOKEN
```

أو عبر واجهة Vercel:
```
Dashboard → Storage → Blob → Upload
```

### **2. تحديث products.json**

بعد رفع الملفات، ضع الروابط في `/data/products.json`:

```json
{
  "product_id": 1,
  "product_name": "دورة تطوير تطبيقات الويب",
  "download_url": "https://YOUR_BLOB_URL.../product.pdf",
  "filename": "web-dev-course.pdf",
  "price": 299.00,
  "currency": "AED",
  ...
}
```

---

## 🔄 التدفق الكامل للنظام

```
┌─────────────────────────────────────────────┐
│ 1️⃣ عميل يدفع على Ziina                     │
│    - يختار منتج                            │
│    - يدخل بيانات الدفع                     │
│    - يُكمل الدفع بنجاح                     │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 2️⃣ Ziina ترسل Webhook                      │
│    POST /api/webhook                        │
│    {                                        │
│      "data": {                              │
│        "id": "payment_id",                  │
│        "status": "completed",               │
│        "amount": 29900,  // بالفلسات       │
│        "customer_email": "user@example.com" │
│      }                                      │
│    }                                        │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 3️⃣ Webhook ينشئ Token آمن                  │
│    - Token: tok_<32 hex chars>             │
│    - Expiry: 10 دقائق                      │
│    - Order Number: ORD-xxx                 │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 4️⃣ حفظ مزدوج في Vercel Blob                │
│    - payments/{payment_id}.json            │
│    - tokens/{token}.json                   │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 5️⃣ Ziina تُحوّل العميل                     │
│    → /order-success?payment_id=xxx         │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 6️⃣ صفحة تجلب السجل                         │
│    GET /api/record?payment_id=xxx          │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 7️⃣ عرض فاتورة + زر تحميل                   │
│    - اسم المنتج الصحيح                     │
│    - صورة المنتج                           │
│    - المبلغ والعملة                        │
│    - زر: /api/download/{token}             │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 8️⃣ عميل يضغط "تحميل المنتج"                │
│    GET /api/download/tok_xxx               │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 9️⃣ Download API يتحقق من Token             │
│    ✓ موجود في Blob                         │
│    ✓ لم ينتهِ (expires_at > now)          │
│    ✓ صالح للاستخدام                       │
└─────────────────────────────────────────────┘
                 ↓
┌─────────────────────────────────────────────┐
│ 🔟 Stream الملف الصحيح بأمان                │
│    - جلب من Blob URL                      │
│    - Stream عبر السيرفر                   │
│    - Headers آمنة                         │
│    - Mark as used                         │
└─────────────────────────────────────────────┘
```

---

## 🔐 الأمان والحماية

### **1. Token Security**

```typescript
// إنشاء token آمن (32 hex chars)
function generateSecureToken(): string {
  const randomPart = randomBytes(16).toString('hex');
  return `tok_${randomPart}`;
}
```

**خصائص الـ Token:**
- ✅ 32 حرف عشوائي (cryptographically secure)
- ✅ صلاحية 10 دقائق
- ✅ فريد لكل دفعة
- ✅ Single-use support (اختياري)

### **2. Time-Limited Access**

```typescript
// صلاحية 10 دقائق
function getExpiryTimestamp(minutes: number = 10): string {
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

// التحقق من الصلاحية
function isTokenExpired(expiresAt: string): boolean {
  return new Date(expiresAt) < new Date();
}
```

### **3. Secure Download**

- ✅ **لا يتم كشف رابط Blob الحقيقي للمستخدم**
- ✅ الملف يُنقل عبر السيرفر (Streaming)
- ✅ Secure HTTP Headers
- ✅ No Caching
- ✅ IP & User-Agent Tracking

### **4. Single-Use Tokens (اختياري)**

لتفعيل single-use، أزل التعليق من الكود التالي في `/app/api/download/[token]/route.ts`:

```typescript
if (record.used) {
  return NextResponse.json({
    error: "Token already used",
    message: "تم استخدام رابط التحميل مسبقاً",
    code: "TOKEN_ALREADY_USED"
  }, { status: 410 });
}
```

---

## 🎯 دعم عدة منتجات

### **كيف يعمل Product Matching؟**

في `/app/api/webhook/route.ts`:

```typescript
function matchProduct(productId?: number, message?: string) {
  // 1. محاولة المطابقة بـ product_id
  if (productId) {
    const product = products.find(p => 
      p.product_id === productId && p.active
    );
    if (product) return product;
  }
  
  // 2. محاولة المطابقة بـ message
  if (message) {
    const product = products.find(p => {
      const nameLower = p.product_name.toLowerCase();
      return nameLower.includes(message.toLowerCase());
    });
    if (product) return product;
  }
  
  // 3. المنتج الافتراضي
  return products[0];
}
```

### **طرق تحديد المنتج:**

#### **1. عبر metadata في Ziina:**
```javascript
// في صفحة الدفع
metadata: {
  product_id: 1
}
```

#### **2. عبر message:**
```javascript
// العميل يكتب في حقل الملاحظات
message: "دورة تطوير الويب"
```

#### **3. افتراضي:**
إذا لم يتم التحديد، يُختار المنتج الأول النشط.

---

## 🧪 الاختبار

### **1. اختبار Webhook يدوياً**

```bash
curl -X POST https://leve1up.vercel.app/api/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "id": "test-payment-12345",
      "status": "completed",
      "amount": 29900,
      "currency_code": "AED",
      "customer_email": "test@example.com",
      "customer_name": "أحمد محمد",
      "message": "دورة تطوير الويب",
      "metadata": {
        "product_id": 1
      }
    }
  }'
```

**النتيجة المتوقعة:**
```json
{
  "success": true,
  "payment_id": "test-payment-12345",
  "access_token": "tok_a3f8c9d2...",
  "redirect_url": "https://leve1up.vercel.app/order-success?payment_id=xxx"
}
```

### **2. اختبار Record API**

```bash
curl "https://leve1up.vercel.app/api/record?payment_id=test-payment-12345"
```

### **3. اختبار Download API**

```bash
curl "https://leve1up.vercel.app/api/download/tok_xxx" -o product.pdf
```

### **4. اختبار الفاتورة**

افتح في المتصفح:
```
https://leve1up.vercel.app/order-success?payment_id=test-payment-12345
```

---

## 📊 المراقبة والتتبع

### **Vercel Logs**

```bash
# عرض logs حية
vercel logs --follow

# تصفية حسب function
vercel logs --filter=api/webhook
vercel logs --filter=api/download
```

### **Console Logging**

كل endpoint يطبع معلومات تفصيلية:

```
═══════════════════════════════════════════════════════════════════
🔔 WEBHOOK RECEIVED
⏰ Timestamp: 2024-11-05T07:25:00.000Z
═══════════════════════════════════════════════════════════════════
📊 PAYMENT DETAILS:
  💳 Payment ID: 24d7813b-2af7-4c89-b9be-040ec8e626a6
  📊 Status: completed
  💰 Amount: 29900 fils = 299.00 AED
───────────────────────────────────────────────────────────────────
📦 PRODUCT MATCHED:
  🆔 Product ID: 1
  📝 Name: دورة تطوير تطبيقات الويب
───────────────────────────────────────────────────────────────────
✅ PAYMENT SAVED SUCCESSFULLY!
💳 Payment ID: 24d7813b-2af7-4c89-b9be-040ec8e626a6
🎫 Token: tok_a3f8c9d2e7b4f1a6...
⏱️ Processing time: 245ms
═══════════════════════════════════════════════════════════════════
```

---

## 🐛 استكشاف الأخطاء

### **المشكلة: Webhook لا يصل**

**الحلول:**
1. تحقق من URL في لوحة Ziina
2. تحقق من أن endpoint متاح: `GET /api/webhook`
3. راجع Vercel logs: `vercel logs --filter=api/webhook`

### **المشكلة: السجل غير موجود**

**الحلول:**
1. انتظر 30-60 ثانية (تأخر Webhook طبيعي)
2. تحقق من Vercel Blob Dashboard
3. تحقق من صحة payment_id

### **المشكلة: Token منتهي**

**الحلول:**
1. التوكنات صالحة لـ 10 دقائق فقط
2. يمكن زيادة المدة في `getExpiryTimestamp(minutes)`
3. عرض زر واتساب للدعم

### **المشكلة: الملف لا يُحمّل**

**الحلول:**
1. تحقق من `download_url` في `products.json`
2. تحقق من وجود الملف في Vercel Blob
3. راجع logs: `vercel logs --filter=api/download`

---

## 🚀 النشر على Vercel

### **1. Push الكود**

```bash
git add .
git commit -m "Complete payment system"
git push origin main
```

### **2. ربط مع Vercel**

```bash
vercel login
vercel link
```

### **3. إضافة Environment Variables**

في Vercel Dashboard:
```
Settings → Environment Variables
```

أضف:
- `BLOB_READ_WRITE_TOKEN`
- `NEXT_PUBLIC_BASE_URL`
- `NEXT_PUBLIC_WHATSAPP_NUMBER`

### **4. Deploy**

```bash
vercel --prod
```

---

## 📝 ملاحظات مهمة

### **1. روابط Blob**

استبدل `YOUR_BLOB_URL` في `products.json` بالروابط الحقيقية من Vercel Blob.

### **2. Product Matching**

للحصول على أفضل مطابقة:
- استخدم `metadata.product_id` في Ziina
- أو تأكد من أن العميل يكتب اسم المنتج بدقة في `message`

### **3. Security**

- ✅ لا تكشف `BLOB_READ_WRITE_TOKEN` علناً
- ✅ استخدم HTTPS فقط
- ✅ راجع logs بانتظام للكشف عن محاولات اختراق

---

## 📞 الدعم

**للأسئلة والمساعدة:**
- 📧 Email: support@leve1up.com
- 💬 WhatsApp: +966500000000
- 🌐 Website: https://leve1up.vercel.app

---

## ✅ Checklist للإعداد

- [ ] إنشاء `.env.local` مع المتغيرات المطلوبة
- [ ] رفع المنتجات إلى Vercel Blob
- [ ] تحديث `products.json` بروابط Blob الحقيقية
- [ ] إعداد Webhook URL في Ziina
- [ ] إعداد Success URL في Ziina
- [ ] اختبار Webhook يدوياً
- [ ] اختبار صفحة الفاتورة
- [ ] اختبار التحميل
- [ ] نشر على Vercel
- [ ] إضافة Environment Variables في Vercel

---

**Made with ❤️ in Saudi Arabia 🇸🇦**

